# Website ini dibuat sebagai bagian dalam proses recruitment ESQ

## Description
website ini dibuat dengan reactjs, ant design dan tailwind CSS. website ini dibuat untuk memudahkan user dalam mencari dan memanage buku-buku dan melihat informasi detail buku tersebut

## Getting Started
To start:

1. Run the following command in directory with package.json
```
npm install
```
2. Next, run the following command in directory with package.json

```
npm run server
```
3. On another terminal, run the following command in directory with package.json

```
npm start
```

## Developers
Diah Putri Lestari
